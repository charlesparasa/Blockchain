/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package in.gov.uidai.auth.sampleapp;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * This class helps in returning the error for a given error number.
 * 
 * @author UIDAI
 *
 */

public class ErrorCodeDescriptions {
	
	private static Map<String, String> map = new HashMap<String, String>();
	
	static {
			  
			map.put("100", "'Pi' (basic) attributes of demographic data did not match.");
			map.put("200", "'Pa' (address) attributes of demographic data did not match");
			map.put("300", "Biometric data did not match");
			map.put("500", "Invalid encryption");
			map.put("500", "Invalid encryption of Skey");
			map.put("501", "Invalid certificate identifier (ci)");
			map.put("502", "Invalid Pid encryption");             
			map.put("503", "Invalid Hmac encryption"); 
			map.put("510", "Invalid Auth XML format");
			map.put("511", "Invalid PID XML format");
			map.put("520", "Invalid device");
			map.put("530", "Invalid authenticator code");
			map.put("540", "Invalid version");
			map.put("550", "Invalid 'Uses' element attributes");
			map.put("561", "Request expired ('Pid->ts' value is older than N hours where N is a configured threshold in authentication server)");
			map.put("562", "Timestamp value is future time (value specified 'Pid->ts' is ahead of authentication server time beyond acceptable threshold)");
			map.put("563", "Duplicate request (this error occurs when exactly same authentication request was re-sent by AUA)");
			map.put("564", "HMAC Validation failed");
			map.put("565", "License key has expired");
			map.put("566", "Invalid license key");
			map.put("567", "Invalid input (this error occurs when some unsupported characters were found in Indian language values; 'lname' or 'lav')");
			map.put("568", "Unsupported Language");
			map.put("569", "Digital signature verification failed (this means that authentication request XML was modified after it was signed)");
			map.put("570", "Invalid key info in digital signature (this means that certificate; used for signing the authentication request is not valid - it is either expired; or does not belong to the AUA or is not created by a well-known (Certification Authority)");
			map.put("571", "PIN Requires reset (this error will be returned if resident is using the default PIN which needs to be reset before usage)");
			map.put("572", "Invalid biometric position (This error is returned if biometric position value - 'pos' attribute in 'Bio' element - is not applicable for a given biometric type - 'type' attribute in 'Bio' element.)");
			map.put("573", "Pi usage not allowed as per license");
			map.put("574", "Pa usage not allowed as per license");
			map.put("575", "Pfa usage not allowed as per license");
			map.put("576", "FMR usage not allowed as per license");
			map.put("577", "FIR usage not allowed as per license");
			map.put("578", "IIR usage not allowed as per license");
			map.put("579", "OTP usage not allowed as per license");
			map.put("580", "PIN usage not allowed as per license");
			map.put("581", "Fuzzy matching usage not allowed as per license");
			map.put("582", "Local language usage not allowed as per license");
			map.put("700", "Invalid demographic data");
			map.put("710", "Missing 'Pi' data as specified in 'Uses'");
			map.put("720", "Missing 'Pa' data as specified in 'Uses'");
			map.put("721", "Missing 'Pfa' data as specified in 'Uses'");
			map.put("730", "Missing PIN data as specified in 'Uses'");
			map.put("740", "Missing OTP data as specified in 'Uses'");
			map.put("800", "Invalid biometric data");
			map.put("810", "Missing biometric data as specified in 'Uses'");
			map.put("811", "Missing biometric data in CIDR for the given Aadhaar number");
			map.put("820", "Missing or empty value for 'bt' attribute in 'Uses' element");
			map.put("821", "Invalid value in the 'bt' attribute of 'Uses' element");
			map.put("901", "No authentication data found in the request (this corresponds to a scenario wherein none of the auth data - Demo; Pv; or Bios - is present)");
			map.put("902", "Invalid 'dob' value in the 'Pi' element (this corresponds to a scenarios wherein 'dob' attribute is not of the format 'YYYY' or 'YYYY-MM-DD'; or the age of resident is not in valid range)");
			map.put("910", "Invalid 'mv' value in the 'Pi' element");
			map.put("911", "Invalid 'mv' value in the 'Pfa' element");
			map.put("912", "Invalid 'ms' value");
			map.put("913", "Both 'Pa' and 'Pfa' are present in the authentication request (Pa and Pfa are mutually exclusive)");
			map.put("930", "Technical error that are internal to authentication server");
			map.put("931", "Technical error that are internal to authentication server");
			map.put("932", "Technical error that are internal to authentication server");
			map.put("933", "Technical error that are internal to authentication server");
			map.put("934", "Technical error that are internal to authentication server");
			map.put("935", "Technical error that are internal to authentication server");
			map.put("936", "Technical error that are internal to authentication server");
			map.put("937", "Technical error that are internal to authentication server");
			map.put("938", "Technical error that are internal to authentication server");
			map.put("939", "Technical error that are internal to authentication server");
			map.put("940", "Unauthorized ASA channel");
			map.put("941", "Unspecified ASA channel");
			map.put("980", "Unsupported option.");
			map.put("996", "Aadhaar cancelled.");
			map.put("997", "Aadhaar suspended.");
			map.put("998", "Invalid aadhaar number/aadhaar data unavailable.");
			map.put("999", "Unknown error");
			
		}
	
	/**
	 * Method to return the error string
	 * 
	 * @param code The error code obtained from authentication response
	 * @return error string
	 */
	
	public static String getDescription(String code) {
		String description = map.get(code);
		if (description == null) {
			description = "Not sure! Please visit aadhaar API site for more info.";
		}
		return description;
	}
	
}

