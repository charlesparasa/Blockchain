package in.gov.uidai.auth.sampleapp;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import in.gov.uidai.auth.aua.helper.AuthRequestCreator;
import in.gov.uidai.auth.aua.helper.AuthResponseValidator;
import in.gov.uidai.auth.aua.helper.AuthResponseValidator.ValidationResult;
import in.gov.uidai.auth.aua.helper.DigitalSigner;
import in.gov.uidai.auth.aua.helper.SignatureVerifier;
import in.gov.uidai.auth.aua.httpclient.AuthClient;
import in.gov.uidai.auth.device.helper.AuthAUADataCreator;
import in.gov.uidai.auth.device.helper.Encrypter;
import in.gov.uidai.auth.device.helper.PidCreator;
import in.gov.uidai.auth.device.model.AuthDataFromDeviceToAUA;
import in.gov.uidai.auth.device.model.AuthResponseDetails;
import in.gov.uidai.auth.device.model.DeviceCollectedAuthData;
import in.gov.uidai.authentication.common.types._1.LocationType;
import in.gov.uidai.authentication.common.types._1.Meta;
import in.gov.uidai.authentication.uid_auth_request._1.Auth;
import in.gov.uidai.authentication.uid_auth_request._1.DataType;
import in.gov.uidai.authentication.uid_auth_request._1.Tkn;
import in.gov.uidai.authentication.uid_auth_request._1.Uses;
import in.gov.uidai.authentication.uid_auth_request._1.UsesFlag;
import in.gov.uidai.authentication.uid_auth_request_data._1.MatchingStrategy;
import in.gov.uidai.authentication.uid_auth_response._1.AuthRes;

/**
 * 
 * This class is where the execution of the project starts.
 * 
 * @author UIDAI
 * @param locationValue -Update the variable with your pincode.
 *
 */


public class SampleClientMainFrame {
	
	//Declare default variables for API call
	static String authServerUrl = "http://auth.uidai.gov.in/1.6";
	static String otpUrl = "http://auth.uidai.gov.in/otp/1.6";
	static String AUA = "public";
	static String subAUA = "public";
	static String terminalId = "public";
	static String asalk = "MH4hSkrev2h_Feu0lBRC8NI-iqzT299_qPSSstOFbNFTwWrie29ThDo";
	static String aualk = "MBFWjkJHNF-fLidl8oOHtUwgL5p1ZjDbWrqsMEVEJLVEDpnlNj_CZTg" ;
	static String publicKey = "./uidai_auth_stage.cer" ;
	static String DSIGPublicKey = "./uidai_auth_stage.cer" ;
	static String signatureFile = "./Staging_Signature_PrivateKey.p12" ;
	static String signatureKeyAlias = "public";
	static char[] signaturePassword = "public".toCharArray();
	static String udc = "UIDAI:SampleClient";
	static String fdc = "NC";
	static String idc = "NA";
	static String publicIP = "127.0.0.1";
	static String locationType = "P";
	static String locationValue = "502205";
	
	//User data variables
	static String aadhaarNumber = "";
	static String aadhaarName = "";
	static String localName = "";
	static String dobType = "";
	static String dob = "";
	static String gender = "";
	static String phone = "";
	static String email = "";
	static String pincode = "";


	private static Map<String, String> tokenLabelToTokenTypeMap = new HashMap<String, String>();
	static {
		tokenLabelToTokenTypeMap.put("Mobile", "001");
	}

	private static AuthClient authClient;
	private static AuthResponseValidator authResponseValidator;
	private static AuthAUADataCreator auaDataCreator = null;

	/**
	 * 
	 * Method to initialize the authClient and otpClient classes and set digital signature and licenseKeys to them.
	 * @return void
	 * 
	 */
	private static void initializeAuthClient() {
		try {
  			
			authClient = new AuthClient(new URL(authServerUrl).toURI());
			
			DigitalSigner ds = new DigitalSigner(signatureFile, signaturePassword,signatureKeyAlias);
			
			authClient.setDigitalSignator(ds);
			
			authClient.setAsaLicenseKey(asalk);

			authResponseValidator = new AuthResponseValidator(new SignatureVerifier(DSIGPublicKey));
			auaDataCreator = new AuthAUADataCreator(new Encrypter(publicKey), true); 			//True for UseSSK
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * Method to put all collected user data into a wrapper and return the wrapper object. 
	 * @return DeviceCollectedAuthData object
	 */
	
	private static DeviceCollectedAuthData constructAuthRequest() {
		DeviceCollectedAuthData request = new DeviceCollectedAuthData();

		String uid = aadhaarNumber;
		request.setUid(uid);

		String Aadhar_name = aadhaarName.trim();
		if ((Aadhar_name != null) && (Aadhar_name.length() > 0)) {
			request.setName(Aadhar_name);
		}
		String lname = localName.trim();
		if ((lname != null) && (lname.length() > 0)) {
			request.setLname(lname);
		}
		
		String phoneNo = phone.trim();
		if ((phoneNo != null) && (phoneNo.length() > 0)) {
			request.setPhoneNo(phoneNo);
		}
		String temp_email = email.trim();
		if ((temp_email != null) && (temp_email.length() > 0)) {
			request.setEmail(temp_email);
		}

		request.setGender(gender);
		request.setDob(dob);

		if (!"Select".equalsIgnoreCase(dobType)) {
			request.setDobType(dobType);
		}
		
		request.setNameMatchValue(100);
		request.setLocalNameMatchValue(100);
		request.setFullAddress("");
		request.setLocalFullAddress("");
		request.setFullAddressMatchValue(1);						// Percent from 1 to 100
		request.setLocalFullAddressMatchValue(1);					// Percent from 1 to 100
		request.setNameMatchStrategy(MatchingStrategy.E);			//Name match strategy

		request.setAddressMatchStrategy(MatchingStrategy.E);
		request.setFullAddressMatchStrategy(MatchingStrategy.E);
		
		Meta m = createMeta();
		request.setDeviceMetaData(m);
		
		return request;

	}

	private static Meta createMeta() {
		Meta m = new Meta();
		m.setFdc(fdc);
		m.setIdc(idc);
		m.setPip(publicIP);
		m.setLot(LocationType.valueOf(locationType));
		m.setLov(pincode);
		m.setUdc(udc);
		return m;
	}
	
	/**
	 * 
	 * 
	 * @param authData The wrapper object consisting of user data 
	 * @param useProto Boolean to tell whether protobuffer is used in the request
	 */

	private static void authenticateRequest(DeviceCollectedAuthData authData, boolean useProto) {
		try {

			try {
				new URL(authServerUrl).openConnection().connect();
			} catch (Exception e) {
				System.out.println("Error! Unable to connect to server.");
				return;
			}

			if (!(new File(publicKey)).exists()) {
				System.out.println("Public key file not found.\nCheck for the file in the path.");
				return;
			}

			if (!(new File(signatureFile)).exists()) {
				System.out.println("Signature key file not found.\nCheck for the file in the path.");
				return;
			}

			Uses usesElement = createUsesElement();
			AuthDataFromDeviceToAUA auaData = null;
			
			if (useProto) {
				auaData = auaDataCreator.prepareAUAData(authData.getUid(), terminalId, authData.getDeviceMetaData(),
						(Object) PidCreator.createProtoPid(authData), DataType.P);
			} else {
				auaData = auaDataCreator.prepareAUAData(authData.getUid(), terminalId,  authData.getDeviceMetaData(),
						(Object) PidCreator.createXmlPid(authData), DataType.X);
			}

			Tkn token = null;
			if (org.apache.commons.lang3.StringUtils.isNotBlank("")) {
				token = new Tkn();
				token.setValue("");
				token.setType(tokenLabelToTokenTypeMap.get(""));
			}
			
			
			AuthRequestCreator authRequestCreator = new AuthRequestCreator();
			Auth auth = authRequestCreator.createAuthRequest(AUA, "public",aualk, usesElement, 
					token, auaData, authData.getDeviceMetaData());

			AuthResponseDetails data = authClient.authenticate(auth);
			AuthRes authResult = data.getAuthRes();

			if (authResult == null) {
				System.out.println("Error while getting response from server.");
				return;
			}
			
			fillAuthResponseValidationText(auth, auaData.getHashedDemoBytes(), authResult, data.getXml());

		} catch (Exception e) {
			System.out.println("Error:" + e.toString());
		}

	}

	//The createUsesElement method tells the API which data should be verified (Check boxes in GUI)
	private static Uses createUsesElement() {
		
		Uses uses = new Uses();
		uses.setPi(UsesFlag.valueOf("Y"));
		uses.setPa(UsesFlag.valueOf("N"));
		uses.setPin(UsesFlag.valueOf("N"));
		uses.setOtp(UsesFlag.valueOf("N"));
		uses.setBio(UsesFlag.valueOf("N"));
		uses.setPfa(UsesFlag.valueOf("N"));

		return uses;
	}
	
	/**
	 *
	 * Method for validation of response
	 * 
	 * @param auth XML element for request
	 * @param responseXML XML response from the server
	 */

	private static void fillAuthResponseValidationText(Auth auth, byte[] hashedDemoXML, AuthRes authResult, String responseXML) {
		
		ValidationResult result = authResponseValidator.validateAuthResponse(auth, hashedDemoXML, authResult, responseXML);
		System.out.println("Authentication Result:");
		if(result.getAuthErrorCode() != null){
			ErrorCodeDescriptions e = new ErrorCodeDescriptions();
			System.out.println("Error: " + e.getDescription(result.getAuthErrorCode()));
		}
		else{
			System.out.println("Aadhaar number " + result.getAadhaarNumber() + " is successfully authenticated.");
		}
		if (!result.isDigitalSignatureVerified()) {
			System.out.println("Signature verification failed.");
		}
	}
	
	
	/**
	 * 
	 * Method to get user details from the console.
	 * @return void
	 * 
	 */
	public static void getUserDetails(){
		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter your Aadhaar Number:");
		aadhaarNumber = reader.nextLine();
		System.out.println("Enter your name as in Aadhaar card:");
		aadhaarName = reader.nextLine();
		System.out.println("Enter your local name(optional,Press enter to skip):");
		localName = reader.nextLine();
		System.out.println("Enter your Date of Birth (YYYY-MM-DD):");
		dob = reader.nextLine();
		System.out.println("Enter your Date of Birth type (V/D/A):");
		dobType = reader.nextLine().toUpperCase();
		System.out.println("Enter your gender(M/F):");
		gender = reader.nextLine().toUpperCase();
		System.out.println("Enter your email ID(optional,Press enter to skip):");
		email = reader.nextLine();
		System.out.println("Enter your phone number(optional,Press enter to skip):");
		phone = reader.nextLine();
		System.out.println("Enter your pincode:");
		pincode = reader.nextLine();
		reader.close();
	}
	
	public static void main(String args[]) {

		getUserDetails();
		initializeAuthClient();
		authenticateRequest(constructAuthRequest(), false);
	}
}